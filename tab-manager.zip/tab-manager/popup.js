'use strict';

// ── State ──────────────────────────────────────────────────────────────────
let allTabs = [];
let currentView = 'all';
let searchQuery = '';

// ── DOM refs ───────────────────────────────────────────────────────────────
const tabList        = document.getElementById('tabList');
const domainGroups   = document.getElementById('domainGroups');
const sessionsView   = document.getElementById('sessionsView');
const sessionsEmpty  = document.getElementById('sessionsEmpty');
const sessionsList   = document.getElementById('sessionsList');
const tabCount       = document.getElementById('tabCount');
const searchInput    = document.getElementById('searchInput');
const searchClear    = document.getElementById('searchClear');
const toast          = document.getElementById('toast');
const modalOverlay   = document.getElementById('modalOverlay');
const sessionNameIn  = document.getElementById('sessionName');

// ── Init ───────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  allTabs = await chrome.tabs.query({});
  updateTabCount();
  renderView();
  bindEvents();
});

function updateTabCount() {
  tabCount.textContent = `${allTabs.length} tab${allTabs.length !== 1 ? 's' : ''} open`;
}

// ── Events ─────────────────────────────────────────────────────────────────
function bindEvents() {
  // Search
  searchInput.addEventListener('input', () => {
    searchQuery = searchInput.value.trim().toLowerCase();
    searchClear.style.display = searchQuery ? 'flex' : 'none';
    renderView();
  });

  searchClear.addEventListener('click', () => {
    searchInput.value = '';
    searchQuery = '';
    searchClear.style.display = 'none';
    searchInput.focus();
    renderView();
  });

  // View tabs
  document.querySelectorAll('.view-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.view-tab').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentView = btn.dataset.view;
      renderView();
    });
  });

  // Header actions
  document.getElementById('btnGroupAll').addEventListener('click', groupAllByDomain);
  document.getElementById('btnSaveSession').addEventListener('click', openSaveModal);
  document.getElementById('btnCloseDuplicates').addEventListener('click', closeDuplicates);

  // Modal
  document.getElementById('modalCancel').addEventListener('click', closeModal);
  document.getElementById('modalSave').addEventListener('click', saveSession);
  modalOverlay.addEventListener('click', e => { if (e.target === modalOverlay) closeModal(); });
  sessionNameIn.addEventListener('keydown', e => { if (e.key === 'Enter') saveSession(); });
}

// ── Render ─────────────────────────────────────────────────────────────────
function renderView() {
  tabList.style.display      = 'none';
  domainGroups.style.display = 'none';
  sessionsView.style.display = 'none';

  if (currentView === 'all') {
    tabList.style.display = 'flex';
    renderTabList();
  } else if (currentView === 'domains') {
    domainGroups.style.display = 'flex';
    renderDomainGroups();
  } else {
    sessionsView.style.display = 'flex';
    renderSessions();
  }
}

// ── All Tabs view ──────────────────────────────────────────────────────────
function renderTabList() {
  const filtered = filterTabs(allTabs);
  tabList.innerHTML = '';

  if (filtered.length === 0) {
    tabList.innerHTML = `<div class="empty-state">
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" opacity="0.5">
        <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
      </svg>
      <span>No tabs match your search</span>
    </div>`;
    return;
  }

  filtered.forEach(tab => tabList.appendChild(createTabItem(tab)));
}

function createTabItem(tab, query = searchQuery) {
  const item = document.createElement('div');
  item.className = `tab-item${tab.active ? ' active-tab' : ''}`;
  item.dataset.tabId = tab.id;

  const title   = highlight(tab.title || 'Untitled', query);
  const urlText = getHost(tab.url);
  const url     = highlight(urlText, query);

  item.innerHTML = `
    ${getFaviconEl(tab)}
    <div class="tab-info">
      <div class="tab-title">${title}</div>
      <div class="tab-url">${url}</div>
    </div>
    <div class="tab-actions">
      <button class="tab-action-btn pin-btn" title="${tab.pinned ? 'Unpin' : 'Pin'}" data-id="${tab.id}">
        <svg width="11" height="11" viewBox="0 0 24 24" fill="${tab.pinned ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2">
          <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/>
        </svg>
      </button>
      <button class="tab-action-btn close-btn" title="Close tab" data-id="${tab.id}">
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
          <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
        </svg>
      </button>
    </div>`;

  // Click row → switch to tab
  item.addEventListener('click', e => {
    if (e.target.closest('.tab-actions')) return;
    chrome.tabs.update(tab.id, { active: true });
    chrome.windows.update(tab.windowId, { focused: true });
  });

  // Pin button
  item.querySelector('.pin-btn').addEventListener('click', async e => {
    e.stopPropagation();
    await chrome.tabs.update(tab.id, { pinned: !tab.pinned });
    allTabs = await chrome.tabs.query({});
    renderView();
  });

  // Close button
  item.querySelector('.close-btn').addEventListener('click', async e => {
    e.stopPropagation();
    await chrome.tabs.remove(tab.id);
    allTabs = allTabs.filter(t => t.id !== tab.id);
    updateTabCount();
    renderView();
    showToast('Tab closed');
  });

  return item;
}

// ── Domain Groups view ─────────────────────────────────────────────────────
function renderDomainGroups() {
  const filtered = filterTabs(allTabs);
  domainGroups.innerHTML = '';

  const byDomain = groupByDomain(filtered);
  const entries  = Object.entries(byDomain).sort((a, b) => b[1].length - a[1].length);

  if (entries.length === 0) {
    domainGroups.innerHTML = `<div class="empty-state"><span>No tabs match your search</span></div>`;
    return;
  }

  entries.forEach(([domain, tabs]) => {
    const group = document.createElement('div');
    group.className = 'domain-group';

    const firstTab = tabs[0];
    const faviconUrl = firstTab.favIconUrl && !firstTab.favIconUrl.startsWith('chrome')
      ? firstTab.favIconUrl : null;

    group.innerHTML = `
      <div class="domain-group-header">
        ${faviconUrl
          ? `<img class="domain-group-favicon" src="${faviconUrl}" onerror="this.style.display='none'">`
          : `<div class="tab-favicon-placeholder">${domain[0].toUpperCase()}</div>`}
        <span class="domain-group-name">${domain}</span>
        <span class="domain-group-badge">${tabs.length}</span>
        <div class="domain-group-actions">
          <button class="tab-action-btn close-btn" title="Close all from ${domain}" style="width:24px;height:24px">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>
        <svg class="domain-group-chevron open" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
          <polyline points="6 9 12 15 18 9"/>
        </svg>
      </div>
      <div class="domain-group-tabs"></div>`;

    const tabsContainer = group.querySelector('.domain-group-tabs');
    const chevron       = group.querySelector('.domain-group-chevron');
    const header        = group.querySelector('.domain-group-header');

    tabs.forEach(tab => tabsContainer.appendChild(createTabItem(tab)));

    // Collapse/expand
    header.addEventListener('click', e => {
      if (e.target.closest('.domain-group-actions')) return;
      const isOpen = tabsContainer.style.display !== 'none';
      tabsContainer.style.display = isOpen ? 'none' : 'flex';
      chevron.classList.toggle('open', !isOpen);
    });

    // Close all in domain
    group.querySelector('.close-btn').addEventListener('click', async e => {
      e.stopPropagation();
      const ids = tabs.map(t => t.id);
      await chrome.tabs.remove(ids);
      allTabs = allTabs.filter(t => !ids.includes(t.id));
      updateTabCount();
      renderView();
      showToast(`Closed ${ids.length} tab${ids.length !== 1 ? 's' : ''} from ${domain}`);
    });

    domainGroups.appendChild(group);
  });
}

// ── Sessions view ──────────────────────────────────────────────────────────
async function renderSessions() {
  const { sessions = [] } = await chrome.storage.local.get('sessions');
  sessionsList.innerHTML = '';

  if (sessions.length === 0) {
    sessionsEmpty.style.display = 'flex';
    return;
  }
  sessionsEmpty.style.display = 'none';

  sessions.slice().reverse().forEach((session, reverseIdx) => {
    const idx = sessions.length - 1 - reverseIdx;
    const card = document.createElement('div');
    card.className = 'session-card';

    const date = new Date(session.savedAt).toLocaleDateString('en-US', {
      month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
    });

    card.innerHTML = `
      <div class="session-card-header">
        <div class="session-icon">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/>
            <polyline points="17 21 17 13 7 13 7 21"/>
          </svg>
        </div>
        <div class="session-info">
          <div class="session-name">${escapeHtml(session.name)}</div>
          <div class="session-meta">${session.tabs.length} tabs · saved ${date}</div>
        </div>
        <div class="session-actions">
          <button class="session-btn restore" data-idx="${idx}">Restore</button>
          <button class="session-btn delete" data-idx="${idx}">Delete</button>
        </div>
      </div>
      <div class="session-urls">
        ${session.tabs.slice(0, 8).map(t =>
          `<div class="session-url-item" title="${escapeHtml(t.url)}">${escapeHtml(t.title || t.url)}</div>`
        ).join('')}
        ${session.tabs.length > 8 ? `<div class="session-url-item" style="opacity:0.5">+${session.tabs.length - 8} more…</div>` : ''}
      </div>`;

    card.querySelector('.restore').addEventListener('click', () => restoreSession(session));
    card.querySelector('.delete').addEventListener('click', async () => {
      sessions.splice(idx, 1);
      await chrome.storage.local.set({ sessions });
      renderSessions();
      showToast('Session deleted');
    });

    sessionsList.appendChild(card);
  });
}

// ── Session helpers ────────────────────────────────────────────────────────
function openSaveModal() {
  sessionNameIn.value = '';
  modalOverlay.style.display = 'flex';
  setTimeout(() => sessionNameIn.focus(), 50);
}

function closeModal() {
  modalOverlay.style.display = 'none';
}

async function saveSession() {
  const name = sessionNameIn.value.trim();
  if (!name) { sessionNameIn.focus(); return; }

  const tabs = allTabs.map(t => ({ title: t.title, url: t.url }));
  const { sessions = [] } = await chrome.storage.local.get('sessions');
  sessions.push({ name, tabs, savedAt: Date.now() });
  await chrome.storage.local.set({ sessions });

  closeModal();
  showToast(`Session "${name}" saved (${tabs.length} tabs)`);
}

async function restoreSession(session) {
  for (const tab of session.tabs) {
    if (tab.url && !tab.url.startsWith('chrome://')) {
      chrome.tabs.create({ url: tab.url, active: false });
    }
  }
  showToast(`Restored ${session.tabs.length} tabs`);
}

// ── Bulk actions ───────────────────────────────────────────────────────────
async function groupAllByDomain() {
  const byDomain = groupByDomain(allTabs.filter(t => !t.pinned));
  for (const [domain, tabs] of Object.entries(byDomain)) {
    if (tabs.length < 2) continue;
    try {
      const groupId = await chrome.tabs.group({ tabIds: tabs.map(t => t.id) });
      await chrome.tabGroups.update(groupId, { title: domain, collapsed: false });
    } catch {
      // tabGroups API may not be available in all contexts
    }
  }
  allTabs = await chrome.tabs.query({});
  renderView();
  showToast('Tabs grouped by domain');
}

async function closeDuplicates() {
  const seen = new Set();
  const toClose = [];
  for (const tab of allTabs) {
    if (seen.has(tab.url)) {
      toClose.push(tab.id);
    } else {
      seen.add(tab.url);
    }
  }
  if (toClose.length === 0) { showToast('No duplicates found'); return; }
  await chrome.tabs.remove(toClose);
  allTabs = allTabs.filter(t => !toClose.includes(t.id));
  updateTabCount();
  renderView();
  showToast(`Closed ${toClose.length} duplicate tab${toClose.length !== 1 ? 's' : ''}`);
}

// ── Utilities ──────────────────────────────────────────────────────────────
function filterTabs(tabs) {
  if (!searchQuery) return tabs;
  return tabs.filter(t =>
    (t.title || '').toLowerCase().includes(searchQuery) ||
    (t.url || '').toLowerCase().includes(searchQuery)
  );
}

function groupByDomain(tabs) {
  return tabs.reduce((acc, tab) => {
    const host = getHost(tab.url);
    if (!acc[host]) acc[host] = [];
    acc[host].push(tab);
    return acc;
  }, {});
}

function getHost(url) {
  try { return new URL(url).hostname || url; } catch { return url || 'unknown'; }
}

function getFaviconEl(tab) {
  if (tab.favIconUrl && !tab.favIconUrl.startsWith('chrome-extension://') && tab.favIconUrl !== '') {
    return `<img class="tab-favicon" src="${tab.favIconUrl}" onerror="this.outerHTML='<div class=tab-favicon-placeholder>${(tab.title||'?')[0]}</div>'">`;
  }
  return `<div class="tab-favicon-placeholder">${(tab.title || '?')[0]}</div>`;
}

function highlight(text, query) {
  if (!query || !text) return escapeHtml(text);
  const safe  = escapeHtml(text);
  const safeQ = escapeHtml(query).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return safe.replace(new RegExp(`(${safeQ})`, 'gi'), '<mark>$1</mark>');
}

function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

let toastTimer;
function showToast(msg) {
  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2200);
}
