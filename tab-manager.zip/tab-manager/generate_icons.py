"""Generate PNG icons for the Tab Manager extension."""
import struct, zlib, math

def png(size):
    """Create a minimal PNG with a gradient circle icon."""
    img = []
    cx = cy = size / 2
    r  = size * 0.42

    for y in range(size):
        row = []
        for x in range(size):
            dx = x - cx
            dy = y - cy
            dist = math.sqrt(dx*dx + dy*dy)
            if dist > r:
                row += [0, 0, 0, 0]
                continue
            # Gradient: purple top-left → blue bottom-right
            t = ((x + y) / (2 * size))
            R = int(120 + (60  - 120) * t)
            G = int(80  + (160 - 80 ) * t)
            B = int(255)
            # Draw two small rounded squares (grid icon)
            sq = size * 0.18
            off = size * 0.14
            in_sq = False
            for (sx, sy) in [(cx - off - sq/2, cy - off - sq/2),
                             (cx + off - sq/2, cy - off - sq/2),
                             (cx - off - sq/2, cy + off - sq/2),
                             (cx + off - sq/2, cy + off - sq/2)]:
                if sx <= x < sx + sq and sy <= y < sy + sq:
                    in_sq = True
                    break
            if in_sq:
                row += [255, 255, 255, 230]
            else:
                row += [R, G, B, 255]
        img.append(row)

    # Build PNG bytes
    def chunk(name, data):
        c = name + data
        return struct.pack('>I', len(data)) + c + struct.pack('>I', zlib.crc32(c) & 0xffffffff)

    sig = b'\x89PNG\r\n\x1a\n'
    ihdr = chunk(b'IHDR', struct.pack('>IIBBBBB', size, size, 8, 6, 0, 0, 0))

    raw = b''
    for row in img:
        raw += b'\x00' + bytes(row)
    idat = chunk(b'IDAT', zlib.compress(raw, 9))
    iend = chunk(b'IEND', b'')
    return sig + ihdr + idat + iend

for sz in [16, 48, 128]:
    with open(f'icons/icon{sz}.png', 'wb') as f:
        f.write(png(sz))
    print(f'Generated icon{sz}.png')
